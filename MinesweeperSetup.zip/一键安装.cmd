@echo off
title Minesweeper Installer
echo ========================================
echo      Minesweeper - One-Click Installer
echo ========================================
echo.

rem Remove old version if exists
powershell -Command "if (Get-AppxPackage -Name 'Minesweeper.Minefield') { Get-AppxPackage -Name 'Minesweeper.Minefield' | Remove-AppxPackage }" >nul 2>&1

echo [1/2] Installing certificate...
certutil -user -addstore Root "%~dp0Minesweeper_TemporaryKey.cer" >nul 2>&1

echo [2/2] Installing Minesweeper...
powershell -Command "Add-AppxPackage -Path '%~dp0Minesweeper.msix'"
if %errorlevel%==0 (
    echo.
    echo ========================================
    echo      INSTALL SUCCESS!
    echo    Launch "Minesweeper" from Start Menu
    echo ========================================
) else (
    echo.
    echo INSTALL FAILED.
    echo Tips:
    echo   - Windows 10 1809 or later required
    echo   - Enable Developer Mode: Settings - Privacy - For developers
    echo   - Or run this script as Administrator
)
echo.
pause
